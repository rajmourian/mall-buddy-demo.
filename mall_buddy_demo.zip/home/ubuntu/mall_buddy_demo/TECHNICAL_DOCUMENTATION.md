# Mall Buddy NFC Navigation Token - Technical Documentation

## Executive Summary

**Mall Buddy** is an innovative indoor navigation system powered by NFC (Near Field Communication) tokens strategically placed throughout shopping malls. The system provides real-time navigation, personalized recommendations, and accessibility features to enhance the shopping experience.

---

## 1. System Architecture

### 1.1 Core Components

```
┌─────────────────────────────────────────────────────────────┐
│                    Mall Buddy System                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │ NFC Tokens   │  │ Mobile App   │  │ Backend      │    │
│  │ (Hardware)   │  │ (Frontend)   │  │ Services     │    │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘    │
│         │                 │                 │             │
│         └─────────────────┼─────────────────┘             │
│                           │                               │
│                    ┌──────▼───────┐                       │
│                    │ Navigation   │                       │
│                    │ Engine       │                       │
│                    └──────┬───────┘                       │
│                           │                               │
│         ┌─────────────────┼─────────────────┐             │
│         │                 │                 │             │
│    ┌────▼────┐    ┌──────▼──────┐   ┌─────▼────┐        │
│    │Pathfind │    │Recommend    │   │Accessib  │        │
│    │Engine   │    │Engine       │   │ility     │        │
│    └────┬────┘    └──────┬──────┘   └─────┬────┘        │
│         │                 │                 │             │
│         └─────────────────┼─────────────────┘             │
│                           │                               │
│                    ┌──────▼───────┐                       │
│                    │ Mall Database│                       │
│                    │ (Locations,  │                       │
│                    │  Routes,     │                       │
│                    │  Stores)     │                       │
│                    └──────────────┘                       │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### 1.2 Technology Stack

| Component | Technology | Purpose |
|-----------|-----------|---------|
| Frontend | HTML5 + CSS3 + JavaScript (ES6+) | Interactive user interface |
| Map Rendering | SVG (Scalable Vector Graphics) | Real-time path visualization |
| Pathfinding | BFS (Breadth-First Search) | Route calculation |
| NFC Simulation | JavaScript Events | Demo NFC tap simulation |
| Backend (Future) | Node.js/Python | Server-side processing |
| Database (Future) | MongoDB/PostgreSQL | Store locations, routes, user data |

---

## 2. NFC Token Specification

### 2.1 Physical Token Design

- **Form Factor**: Credit card-sized or keychain attachment
- **NFC Chip**: NFC Type 4 (ISO/IEC 14443 Type A)
- **Data Capacity**: 64-4096 bytes
- **Read Range**: 5-10 cm (typical)
- **Power Source**: Passive (powered by reader)

### 2.2 Token Data Structure

```json
{
  "tokenId": "MBT-2025-001",
  "locationId": "entrance_a",
  "locationName": "Entrance A",
  "coordinates": {
    "x": 35,
    "y": 25
  },
  "type": "entrance",
  "timestamp": "2025-11-06T10:30:00Z",
  "version": "1.0"
}
```

### 2.3 NFC Communication Flow

```
User with Smartphone
        │
        │ (Tap NFC Token)
        ▼
NFC Token (Passive)
        │
        │ (NDEF Message)
        ▼
Mobile App
        │
        │ (Parse Location Data)
        ▼
Update User Position
        │
        ├─► Fetch Recommendations
        ├─► Calculate Route
        └─► Update Map Display
```

---

## 3. Core Features

### 3.1 Real-Time Navigation

**Algorithm**: Breadth-First Search (BFS)

```javascript
// Simplified pseudocode
function findPath(start, destination) {
    queue = [[start]]
    visited = {start}
    
    while queue is not empty:
        path = queue.pop()
        lastNode = path[-1]
        
        if lastNode == destination:
            return path
        
        for neighbor in adjacentNodes(lastNode):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.push(path + [neighbor])
    
    return null  // No path found
}
```

**Complexity**: O(V + E) where V = vertices, E = edges

**Advantages**:
- Guaranteed shortest path in unweighted graphs
- Simple and efficient for mall layouts
- Easy to implement and debug

### 3.2 Recommendation Engine

The system analyzes:
- Current location
- Historical shopping patterns (future)
- Time of day
- Special promotions
- User preferences (future)

**Example Logic**:
```javascript
function getRecommendations(location) {
    const baseRecommendations = MALL_MAP[location].recommendations;
    const timeBasedOffers = getTimeBasedOffers(location);
    const proximityOffers = getNearbyStoreOffers(location);
    
    return mergeAndRank([
        ...baseRecommendations,
        ...timeBasedOffers,
        ...proximityOffers
    ]);
}
```

### 3.3 Accessibility Features

#### Voice Guidance
- **Technology**: Web Speech API (text-to-speech)
- **Languages**: English, Spanish, Mandarin (expandable)
- **Features**:
  - Turn-by-turn directions
  - Location announcements
  - Emergency assistance alerts

#### Wheelchair-Accessible Routes
- **Avoids**: Stairs, escalators, steep ramps
- **Prioritizes**: Elevators, accessible entrances, wide corridors
- **Metadata**: Slope angles, surface types, door widths

#### Visual Accessibility
- **High Contrast Mode**: Enhanced color differentiation
- **Large Text Option**: Scalable fonts
- **Haptic Feedback**: Vibration patterns for navigation cues

---

## 4. Data Models

### 4.1 Location Model

```javascript
const Location = {
    id: String,              // Unique identifier
    name: String,            // Display name
    type: String,            // 'entrance', 'food', 'retail', 'utility'
    coordinates: {
        x: Number,           // SVG X coordinate
        y: Number            // SVG Y coordinate
    },
    recommendations: [String],  // Array of recommendations
    accessibility: {
        wheelchairAccessible: Boolean,
        elevatorNearby: Boolean,
        restroomNearby: Boolean
    },
    stores: [String]         // Nearby stores
};
```

### 4.2 Route Model

```javascript
const Route = {
    id: String,              // Unique identifier
    startLocation: String,   // Starting location ID
    endLocation: String,     // Destination location ID
    path: [String],          // Array of location IDs in sequence
    distance: Number,        // Distance in meters
    estimatedTime: Number,   // Time in seconds
    accessible: Boolean,     // Wheelchair accessible
    waypoints: [Object]      // Intermediate points
};
```

### 4.3 User Profile Model (Future)

```javascript
const UserProfile = {
    userId: String,
    preferences: {
        language: String,
        accessibilityNeeds: [String],
        favoriteStores: [String],
        dietaryRestrictions: [String]
    },
    history: {
        frequentLocations: [String],
        visitedStores: [String],
        searchHistory: [String]
    },
    notifications: {
        promotions: Boolean,
        newStores: Boolean,
        events: Boolean
    }
};
```

---

## 5. Implementation Details

### 5.1 Frontend Architecture

**File Structure**:
```
mall_buddy_demo/
├── index.html           # Main HTML structure
├── style.css            # Styling and layout
├── script.js            # Core JavaScript logic
└── TECHNICAL_DOCUMENTATION.md
```

### 5.2 Key JavaScript Functions

| Function | Purpose | Parameters |
|----------|---------|-----------|
| `simulateTap()` | Simulates NFC token tap | locationName: String |
| `startNavigation()` | Initiates route calculation | None (uses form input) |
| `findPath()` | Calculates shortest route | start: String, end: String |
| `drawPath()` | Visualizes route on map | path: Array<String> |
| `updateRecommendations()` | Updates recommendation list | recommendations: Array<String> |
| `toggleAccessibility()` | Applies accessibility features | None (uses checkboxes) |

### 5.3 SVG Map Rendering

The mall layout is rendered using SVG for:
- **Scalability**: Works on any screen size
- **Performance**: Lightweight and fast
- **Interactivity**: Easy to add click handlers
- **Animation**: Smooth path drawing

**Map Elements**:
- Rectangles for location zones
- Circles for user position marker
- Paths for navigation routes
- Text labels for location names

---

## 6. Future Enhancements

### 6.1 Advanced Features

1. **Machine Learning Integration**
   - Predictive recommendations based on user behavior
   - Anomaly detection for lost shoppers
   - Optimal route suggestions

2. **Real-Time Inventory**
   - Live stock information for stores
   - "Find in Store" feature
   - Queue length predictions

3. **Social Features**
   - Meet friends at locations
   - Share favorite routes
   - Community reviews

4. **Augmented Reality (AR)**
   - AR navigation overlays
   - Virtual store previews
   - Interactive product displays

### 6.2 Backend Services

```
┌─────────────────────────────────────────┐
│ Backend Services (Future)               │
├─────────────────────────────────────────┤
│                                         │
│ ┌──────────────────────────────────┐   │
│ │ User Service                     │   │
│ │ - Authentication & Authorization │   │
│ │ - Profile Management             │   │
│ └──────────────────────────────────┘   │
│                                         │
│ ┌──────────────────────────────────┐   │
│ │ Navigation Service               │   │
│ │ - Route Calculation              │   │
│ │ - Real-time Updates              │   │
│ └──────────────────────────────────┘   │
│                                         │
│ ┌──────────────────────────────────┐   │
│ │ Recommendation Service           │   │
│ │ - Personalized Suggestions       │   │
│ │ - Promotion Management           │   │
│ └──────────────────────────────────┘   │
│                                         │
│ ┌──────────────────────────────────┐   │
│ │ Analytics Service                │   │
│ │ - Usage Tracking                 │   │
│ │ - Heat Maps                      │   │
│ └──────────────────────────────────┘   │
│                                         │
└─────────────────────────────────────────┘
```

### 6.3 Integration with Mall Systems

- **POS Systems**: Real-time inventory sync
- **Security Systems**: Crowd management
- **Marketing Platforms**: Targeted promotions
- **Accessibility Services**: Emergency assistance

---

## 7. Security Considerations

### 7.1 NFC Security

- **Encryption**: AES-128 for sensitive data
- **Authentication**: HMAC-SHA256 for token verification
- **Anti-cloning**: Unique cryptographic signatures

### 7.2 Data Privacy

- **User Data**: Encrypted at rest and in transit
- **GDPR Compliance**: User consent for tracking
- **Data Retention**: Automatic purging after 90 days
- **Anonymization**: Option to use anonymous mode

### 7.3 Application Security

- **Input Validation**: Sanitize all user inputs
- **XSS Prevention**: Content Security Policy headers
- **CSRF Protection**: Token-based request verification

---

## 8. Performance Metrics

| Metric | Target | Current |
|--------|--------|---------|
| NFC Tap Recognition | < 500ms | ~200ms (demo) |
| Route Calculation | < 1s | ~100ms (demo) |
| Map Rendering | 60 FPS | 60 FPS |
| Recommendation Load | < 2s | ~500ms (demo) |
| Voice Guidance Start | < 3s | ~1s (demo) |

---

## 9. Testing Strategy

### 9.1 Unit Tests
- Location data validation
- Pathfinding algorithm correctness
- Recommendation ranking logic

### 9.2 Integration Tests
- NFC token parsing
- Navigation flow end-to-end
- Accessibility feature interactions

### 9.3 User Acceptance Tests
- Real-world mall navigation
- Accessibility user feedback
- Performance under load

---

## 10. Deployment Architecture

```
┌──────────────────────────────────────────────────────┐
│ Deployment Infrastructure                           │
├──────────────────────────────────────────────────────┤
│                                                      │
│  ┌─────────────────────────────────────────────┐   │
│  │ CDN (Content Delivery Network)              │   │
│  │ - Static Assets (HTML, CSS, JS)             │   │
│  │ - Map Data                                  │   │
│  └─────────────────────────────────────────────┘   │
│                                                      │
│  ┌─────────────────────────────────────────────┐   │
│  │ API Gateway                                 │   │
│  │ - Request Routing                           │   │
│  │ - Rate Limiting                             │   │
│  │ - Authentication                            │   │
│  └─────────────────────────────────────────────┘   │
│                                                      │
│  ┌─────────────────────────────────────────────┐   │
│  │ Microservices (Containerized)               │   │
│  │ - Navigation Service                        │   │
│  │ - Recommendation Service                    │   │
│  │ - User Service                              │   │
│  └─────────────────────────────────────────────┘   │
│                                                      │
│  ┌─────────────────────────────────────────────┐   │
│  │ Database Layer                              │   │
│  │ - PostgreSQL (Relational Data)              │   │
│  │ - Redis (Caching)                           │   │
│  │ - Elasticsearch (Search)                    │   │
│  └─────────────────────────────────────────────┘   │
│                                                      │
└──────────────────────────────────────────────────────┘
```

---

## 11. Conclusion

Mall Buddy represents a next-generation approach to indoor navigation and shopping experience enhancement. By combining NFC technology with intelligent software, the system provides a seamless, accessible, and personalized experience for all shoppers.

**Key Innovations**:
- ✅ Passive NFC tokens (no battery required)
- ✅ Real-time navigation with accessibility features
- ✅ Personalized recommendations
- ✅ Scalable architecture for enterprise deployment

**Contact & Support**: For technical inquiries, contact the development team.
