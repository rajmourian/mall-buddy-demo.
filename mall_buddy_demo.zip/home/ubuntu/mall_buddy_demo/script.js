// --- 1. Data Structure: Mall Map and Locations ---
const MALL_MAP = {
    "Entrance A": { x: 35, y: 25, recommendations: ["Coffee Shop (10% off)", "Information Desk"], type: "Entrance" },
    "Food Court": { x: 365, y: 25, recommendations: ["Burger Joint", "Smoothie Bar (New!)"], type: "Food" },
    "Store X": { x: 200, y: 165, recommendations: ["Store X: New Arrivals", "Shoe Store nearby"], type: "Retail" },
    "Restroom": { x: 100, y: 250, recommendations: [], type: "Utility" },
    "Elevator": { x: 300, y: 250, recommendations: [], type: "Utility" },
    "Center Hub": { x: 200, y: 50, recommendations: [], type: "Hub" } // Virtual node for routing
};

// Simplified path data (connecting nodes)
const PATHS = {
    "Entrance A": { "Center Hub": 1, "Restroom": 2 },
    "Center Hub": { "Entrance A": 1, "Store X": 1, "Food Court": 2 },
    "Store X": { "Center Hub": 1, "Elevator": 1 },
    "Food Court": { "Center Hub": 2, "Elevator": 1 },
    "Restroom": { "Entrance A": 2, "Elevator": 1 },
    "Elevator": { "Store X": 1, "Food Court": 1, "Restroom": 1 }
};

let currentLocation = null;
let currentPathElement = null;

// --- 2. Core Functions ---

/**
 * Simulates the user tapping an NFC token at a specific location.
 * This is the core "Mall Buddy" interaction.
 * @param {string} locationName - The name of the location tapped.
 */
function simulateTap(locationName) {
    currentLocation = locationName;
    const locationData = MALL_MAP[locationName];

    // Update UI
    document.getElementById('current-location').textContent = `Current Location: ${locationName} (NFC Token Scanned)`;
    document.getElementById('nfc-simulation').style.display = 'none';
    document.getElementById('main-interface').style.display = 'flex';

    // Update Map Marker
    updateMapMarker(locationData.x, locationData.y);

    // Update Recommendations
    updateRecommendations(locationData.recommendations);

    // Clear previous directions
    document.getElementById('directions-output').textContent = '';
    if (currentPathElement) {
        currentPathElement.remove();
        currentPathElement = null;
    }

    // Inform user
    alert(`Welcome to ${locationName}! Your Mall Buddy token has updated your location.`);
}

/**
 * Updates the user's position marker on the SVG map.
 * @param {number} x - X coordinate on the SVG.
 * @param {number} y - Y coordinate on the SVG.
 */
function updateMapMarker(x, y) {
    const marker = document.getElementById('user-marker');
    marker.setAttribute('cx', x);
    marker.setAttribute('cy', y);
    marker.style.display = 'block';
}

/**
 * Updates the recommendations list based on the current location.
 * @param {string[]} recommendations - List of recommendations.
 */
function updateRecommendations(recommendations) {
    const list = document.getElementById('recommendations-list');
    list.innerHTML = '';
    if (recommendations.length === 0) {
        list.innerHTML = '<li>No special recommendations nearby.</li>';
        return;
    }
    recommendations.forEach(rec => {
        const li = document.createElement('li');
        li.textContent = rec;
        list.appendChild(li);
    });
}

/**
 * Starts the navigation process to the selected destination.
 */
function startNavigation() {
    if (!currentLocation) {
        alert("Please simulate an NFC tap first to set your starting location.");
        return;
    }

    const destination = document.getElementById('destination-select').value;
    if (!destination) {
        document.getElementById('directions-output').textContent = 'Please select a destination.';
        return;
    }

    if (currentLocation === destination) {
        document.getElementById('directions-output').textContent = `You are already at ${destination}!`;
        return;
    }

    // Simulate pathfinding (using a simplified path for demo)
    const path = findPath(currentLocation, destination);
    const pathString = path.join(' -> ');
    const distance = path.length * 100; // Mock distance

    // Update directions output
    document.getElementById('directions-output').textContent =
        `Route found: ${pathString}. Estimated distance: ${distance} meters.`;

    // Draw path on map
    drawPath(path);

    // Handle accessibility features
    const isVoiceEnabled = document.getElementById('voice-guidance').checked;
    const isWheelchairEnabled = document.getElementById('wheelchair-route').checked;

    if (isVoiceEnabled) {
        // Simulate voice guidance
        document.getElementById('directions-output').textContent += "\n(Voice Guidance: 'Starting navigation. Head towards the " + path[1] + "')";
    }

    if (isWheelchairEnabled) {
        // Simulate wheelchair route adjustment
        document.getElementById('directions-output').textContent += "\n(Wheelchair Route: Avoiding stairs/escalators. Route may be slightly longer.)";
        // Visually update the path to show it's an accessible route
        if (currentPathElement) {
            currentPathElement.classList.add('accessible-path');
        }
    } else {
        if (currentPathElement) {
            currentPathElement.classList.remove('accessible-path');
        }
    }
}

/**
 * Toggles accessibility features and updates the map/directions if navigation is active.
 */
function toggleAccessibility() {
    const destination = document.getElementById('destination-select').value;
    if (destination) {
        // Re-run navigation logic to apply new accessibility settings
        startNavigation();
    }
}

// --- 3. Pathfinding and Drawing (Simplified for Demo) ---

/**
 * Simplified Breadth-First Search (BFS) for pathfinding.
 * @param {string} start - Starting location.
 * @param {string} end - Destination location.
 * @returns {string[]} - Array of location names representing the path.
 */
function findPath(start, end) {
    // In a real system, this would be a complex A* or Dijkstra's algorithm
    // For the demo, we use a simple, pre-defined logic based on the PATHS object.
    const queue = [[start]];
    const visited = new Set([start]);

    while (queue.length > 0) {
        const path = queue.shift();
        const lastNode = path[path.length - 1];

        if (lastNode === end) {
            return path;
        }

        const neighbors = Object.keys(PATHS[lastNode] || {});
        for (const neighbor of neighbors) {
            if (!visited.has(neighbor)) {
                visited.add(neighbor);
                const newPath = [...path, neighbor];
                queue.push(newPath);
            }
        }
    }

    // Fallback for unroutable locations
    return [start, "Path Not Found", end];
}

/**
 * Draws the calculated path on the SVG map.
 * @param {string[]} path - Array of location names in the path.
 */
function drawPath(path) {
    if (currentPathElement) {
        currentPathElement.remove();
    }

    const svg = document.getElementById('mall-map');
    let d = "M"; // SVG path data string

    // Build the path string from coordinates
    for (let i = 0; i < path.length; i++) {
        const loc = MALL_MAP[path[i]];
        if (loc) {
            d += `${loc.x} ${loc.y}`;
            if (i < path.length - 1) {
                d += " L";
            }
        }
    }

    // Create the path element
    currentPathElement = document.createElementNS("http://www.w3.org/2000/svg", "path");
    currentPathElement.setAttribute('d', d);
    currentPathElement.setAttribute('class', 'path');

    // Insert the path before the user marker so the marker is on top
    const marker = document.getElementById('user-marker');
    svg.insertBefore(currentPathElement, marker);
}

// Add the Center Hub to the map visually (optional, but good for clarity)
function drawCenterHub() {
    const svg = document.getElementById('mall-map');
    const hub = MALL_MAP["Center Hub"];

    const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle");
    circle.setAttribute('cx', hub.x);
    circle.setAttribute('cy', hub.y);
    circle.setAttribute('r', 8);
    circle.setAttribute('fill', '#9C27B0');
    circle.setAttribute('opacity', 0.5);
    svg.appendChild(circle);

    const text = document.createElementNS("http://www.w3.org/2000/svg", "text");
    text.setAttribute('x', hub.x);
    text.setAttribute('y', hub.y + 15);
    text.setAttribute('font-size', 8);
    text.setAttribute('text-anchor', 'middle');
    text.setAttribute('fill', '#9C27B0');
    text.textContent = 'Hub';
    svg.appendChild(text);
}

// Initialize the map with the Center Hub
document.addEventListener('DOMContentLoaded', drawCenterHub);
